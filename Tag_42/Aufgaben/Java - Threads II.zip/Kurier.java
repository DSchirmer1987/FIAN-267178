
public class Kurier extends Thread {
	// Ihr Code aus Aufgabe a)
}
