
public class PizzaSync {

	/*
	 * Wird vom Pizzaiolo verwendet, um eine Pizza zur Auslieferung zu übergeben;
	 * blockiert, wenn der Kurier beschäftigt ist
	 */
	public synchronized void lieferePizza(int pizza) {
		// Ihr Code aus Aufgabe b)
	}

	/*
	 * Wird vom Kurier verwendet, um eine Pizza zur Auslieferung abzuholen;
	 * blockiert, wenn keine Pizza bereit
	 */
	public synchronized int getPizza() {
		// Ihr Code aus Aufgabe b)
	}

	/* Wird vom Kurier verwendet, wenn er eine Pizza ausgeliefert hat */
	public synchronized void pizzaGeliefert() {
		// Ihr Code aus Aufgabe b)
	}
}
