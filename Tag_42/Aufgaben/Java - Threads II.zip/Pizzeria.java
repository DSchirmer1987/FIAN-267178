
public class Pizzeria {

	public static void main(String args[]) {
		// Ihr Code aus Aufgabe c)
	}
}
